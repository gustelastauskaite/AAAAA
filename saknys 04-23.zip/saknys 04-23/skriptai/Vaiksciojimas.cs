using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Vaiksciojimas : MonoBehaviour
{
    private float runspeed = 8f;
    private float horizontal;
    private float vertical;
    private bool isJumping;

    [SerializeField] private Rigidbody2D rb;
    [SerializeField] private Transform GroundCheck;
    [SerializeField] private LayerMask GroundLayer;

    void Update()
    {
        horizontal = Input.GetAxisRaw("Horizontal");
        vertical = Input.GetAxisRaw("Vertical");
    
        rb.velocity = new Vector2(horizontal * runspeed, vertical * runspeed);        

        if (Input.GetButtonUp("Jump") && !!isJumping)
        {
            isJumping = true;
        }
    }


    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.CompareTag("Ground"))
        {
            isJumping = false;
        }
    }

    void FixedUpdate ()
    {
        rb.velocity = new Vector2(horizontal * runspeed, rb.velocity.y);
    }

    public bool isGrounded()
    {
        return Physics2D.OverlapCircle(GroundCheck.position, 0.2f, GroundLayer);
    }

  }


