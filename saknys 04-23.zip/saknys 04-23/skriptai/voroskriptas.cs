using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class voroskriptas : MonoBehaviour
{
    public GameObject taskasC;
    public GameObject taskasD;
    private Rigidbody2D rb;
    private Transform currentPoint;
    public float moveSpeed;

        void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        currentPoint = taskasC.transform;
    }

        void Update()
    {
        Vector2 point = currentPoint.position - transform.position;

         if(currentPoint == taskasD.transform)
        { 
            rb.velocity = new Vector2(0, moveSpeed);
        }

        else
        {
            rb.velocity = new Vector2(0, -moveSpeed);
        }

         if(Vector2.Distance(transform.position, currentPoint.position)< 0.5f && currentPoint == taskasD.transform)
        { 
            currentPoint = taskasC.transform;
        }

         if(Vector2.Distance(transform.position, currentPoint.position)< 0.5f && currentPoint == taskasC.transform)
        { 
            currentPoint = taskasD.transform;
        }

    }

}

