using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Health : MonoBehaviour
{

public float maxHealth = 5;
public float currentHealth;

        public void Start()
    {
        currentHealth = maxHealth;
    }

       public void TakeDamage(float amount)
    {
        currentHealth -= amount;
        if (currentHealth <= 0)
        {                
             SceneManager.LoadScene(2);
        }
    }

       public void AddHealth(float amount1)
    {
        currentHealth += amount1;
    }
}
