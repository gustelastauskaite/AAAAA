using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class gyvybes : MonoBehaviour
{
public float damage;
    
void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            collision.GetComponent<Health>().TakeDamage(damage);
        }
    }

}
