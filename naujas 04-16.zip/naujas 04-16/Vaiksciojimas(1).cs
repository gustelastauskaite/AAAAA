using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Vaiksciojimas : MonoBehaviour
{
    float runspeed = 8f;
    float horizontal;
    float jumpingPower = 16f;
    bool jump = false;
    bool crouch = false;
    bool isfacingright = true;

    [SerializeField] public Rigidbody2D rb = gameObject.GetComponent<Rigidbody2D>();
    [SerializeField] public Transform groundcheck;
    [SerializeField] public LayerMask groundlayer;

    
    // Update is called once per frame
    void Update()
    {
        horizontal = Input.GetAxisRaw("Horizontal") * runspeed;
        if (Input.GetButtonDown("Jump") && isGrounded())
        {
            rb.velocity = new Vector2(rb.velocity.x, jumpingPower);
        }
        if (Input.GetButtonUp("Jump") && rb.velocity.y >0f)
        {
            rb.velocity = new Vector2(rb.velocity.x, rb.velocity.y * 0.5f);
        }
        
    }

    void FixedUndate ()
    {
        //Move our character
        rb.velocity = new Vector2(horizontal * Time.fixedDeltaTime, rb.velocity.y);
        
        jump = false;
    }

    public bool isGrounded()
    {
        return Physics2D.OverlapCircle(groundcheck.position, 0.2f, groundlayer);
    }

    public void flip()
    {
        if (isfacingright&&horizontal<0f || isfacingright&&horizontal>0f)
        {
            isfacingright = !isfacingright;
            Vector3 localScale = transform.localScale;
            localScale.x *= -1f;
            transform.localScale = localScale;
        }
    }


}

