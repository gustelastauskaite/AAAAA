using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ziogoskriptas : MonoBehaviour
{
    public GameObject taskasA;
    public GameObject taskasB;
    private Rigidbody2D rb;
    private Transform currentPoint;
    public float moveSpeed;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        currentPoint = taskasA.transform;
    }

    void Update()
    {
        Vector2 point = currentPoint.position - transform.position;

        if(currentPoint == taskasB.transform)
        { 
            rb.velocity = new Vector2(moveSpeed, 0);
        }

        else
        {
            rb.velocity = new Vector2(-moveSpeed, 0);
        }

        if(Vector2.Distance(transform.position, currentPoint.position)< 0.5f && currentPoint == taskasB.transform)
        { 
            flip();
            currentPoint = taskasA.transform;
        }

        if(Vector2.Distance(transform.position, currentPoint.position)< 0.5f && currentPoint == taskasA.transform)
        { 
            flip();
            currentPoint = taskasB.transform;
        }

    }
    private void flip()
    {
        Vector3 localScale = transform.localScale;
        localScale.x *= -1;
        transform.localScale = localScale;
    }

}

