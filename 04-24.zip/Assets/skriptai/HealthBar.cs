using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HealthBar : MonoBehaviour
{

public Health playerHealth;
public Image TotatHealthBar;
public Image CurrentHealthBar;

    void Start()
    {
        TotatHealthBar.fillAmount = playerHealth.currentHealth / 5;
    }

    void Update()
    {
        CurrentHealthBar.fillAmount = playerHealth.currentHealth / 5;
    }
}
